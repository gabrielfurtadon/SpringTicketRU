package br.com.Gabriel.APIPaymentsEFI.gerencianet.pix.pix.controller;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.Gabriel.APIPaymentsEFI.gerencianet.pix.service.PixService;

@RestController
@RequestMapping("/pix")
public class PixController {
    private final PixService pixService;

    public PixController(PixService pixService) {
        this.pixService = pixService;
    }

    @PostMapping("/copia-cola")
    public ResponseEntity<JSONObject> createPixCopiaCola(@RequestBody PixRequest request) throws Exception {
        JSONObject response = pixService.createPixCopiaCola(request.getChavePix(), request.getValor(),
                request.getDescricao());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/qr-code")
    public ResponseEntity<JSONObject> createPixQRCode(@RequestBody PixRequest request) throws Exception {
        JSONObject response = pixService.createPixQRCode(request.getChavePix(), request.getValor(),
                request.getDescricao());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
