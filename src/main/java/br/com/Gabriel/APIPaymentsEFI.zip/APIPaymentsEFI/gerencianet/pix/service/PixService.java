package br.com.Gabriel.APIPaymentsEFI.gerencianet.pix.service;

import br.com.Gabriel.APIPaymentsEFI.gerencianet.Credentials;
import br.com.gerencianet.gnsdk.Gerencianet;
import br.com.gerencianet.gnsdk.exceptions.GerencianetException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public class PixService {
    private final Gerencianet gn;
    Credentials credentials = new Credentials();

    public PixService() throws Exception {
        Credentials credentials = new Credentials();
        System.out.println("CREDENCIAIS" + credentials.getClientId());

        JSONObject options = new JSONObject();
        options.put("client_id", credentials.getClientId());
        options.put("client_secret", credentials.getClientSecret());
        options.put("sandbox", credentials.isSandbox());

        try {
            gn = new Gerencianet(options);
        } catch (GerencianetException e) {
            // Handle the exception appropriately
            System.out.println(e.getError());
            System.out.println(e.getErrorDescription());
            throw new RuntimeException("Failed to initialize Gerencianet SDK");
        }
    }

    public JSONObject createPixCopiaCola(String chavePix, double valor, String descricao) throws Exception {
        HashMap<String, String> params = new HashMap<>();
        params.put("chave", chavePix);

        JSONObject body = new JSONObject();
        body.put("valor", valor);
        body.put("pagador", new JSONObject().put("descricao", descricao));

        try {
            return gn.call("pixCreateImmediateCharge", params, body);
        } catch (GerencianetException e) {
            // Handle the exception appropriately
            System.out.println(e.getError());
            System.out.println(e.getErrorDescription());
            throw new RuntimeException("Failed to create PIX copia e cola");
        }
    }

    public JSONObject createPixQRCode(String chavePix, double valor, String descricao) throws Exception {
        HashMap<String, String> params = new HashMap<>();
        params.put("chave", chavePix);

        JSONObject body = new JSONObject();
        body.put("valor", valor);
        body.put("pagador", new JSONObject().put("descricao", descricao));

        try {
            return gn.call("pixCreateCharge", params, body);
        } catch (GerencianetException e) {
            // Handle the exception appropriately
            System.out.println(e.getError());
            System.out.println(e.getErrorDescription());
            throw new RuntimeException("Failed to create PIX QR code");
        }
    }

    // call create pix copia e cola
    public static void main(String[] args) throws Exception {
        PixService pixService = new PixService();
        JSONObject response = pixService.createPixCopiaCola("71198826436", 0.01, "Serviço realizado.");
        System.out.println(response);
    }

}
