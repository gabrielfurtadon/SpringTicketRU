package br.com.Gabriel.APIPaymentsEFI.gerencianet.pix.pix.controller;

@lombok.Getter
@lombok.Setter
public class PixRequest {
    private String chavePix;
    private double valor;
    private String descricao;

}
